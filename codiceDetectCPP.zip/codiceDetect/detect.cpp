#include <iostream>
#include <vector>
#include <cstdlib> // per rand() e srand()
#include <ctime> // per time()
#include <fstream>
#include <string>
#include <sstream>
#include <cmath>

#define THRASHOLD_SEGENMENTATION_DERIVATIVE 50
#define WINDOW_SIZE_SMOOTH 1

struct Point {
    float x, y;     // coordinates

    Point(float r, float th) : 
        // conversion from polar to cartesian
        x(r*cos(th)), // x = radiuscos(theta)
        y(r*sin(th)) // y = radiussin(theta)
    {}
    
    Point(float x_input, float y_input,bool is_cartesian) : 
        // conversion from polar to cartesian
        x(x_input), // x = radiuscos(theta)
        y(y_input) // y = radiussin(theta)
    {}
};

std::vector<Point> circle_centers(std::vector<float> ranges, float incrementTheta);
std::vector<float> clean_first_20(std::vector<float> ranges);
void divide_in_segment(std::vector<float> ranges,std::vector<float> f_deriv, std::vector<std::vector<float>> &segmentedData, std::vector<int> &segment_index_begin);
void calc_first_derivative_polar(std::vector<float> data, std::vector<float> &output, float incrementTheta);
void segmentPolar_to_segmentCartesian(std::vector<std::vector<float>> segmentedData, std::vector<std::vector<Point>> &segmentedDataCartesian, float initial_theta, float incrementTheta);
std::vector<std::vector<Point>>smooth_data_cartesian(std::vector<std::vector<Point>> dataSegemntedPoint, int window_size);


float findiff(float fx, float fxh, float h) {
    return (fxh - fx) / h;
}
int main() {
    //inizio debug lettura file
    //inizializza il generatore di numeri casuali
    std::vector<float> distanze;
    //leggi il file di nome data.txt
    std::string nome_file = "data.txt";

    // Apri il file in modalità di lettura
    std::ifstream file_input(nome_file);

    if (!file_input.is_open()) {
        std::cerr << "Impossibile aprire il file: " << nome_file << std::endl;
        return 1; // Termina il programma con un codice di errore
    }

    // Leggi il contenuto del file
    std::string linea;
    while (std::getline(file_input, linea)) {
        // Utilizza un stringstream per analizzare i numeri da ogni riga
        std::stringstream stream_linea(linea);
        
        std::string numero_str;
        while (std::getline(stream_linea, numero_str, ',')) {
            try {
                // Converte la stringa in un numero double e lo aggiunge al vettore
                double numero = std::stof(numero_str);
                distanze.push_back(numero);
            } catch (const std::invalid_argument& e) {
                std::cerr << "Errore nella conversione del numero: o"<< numero_str <<"o " << e.what()<< std::endl;
            }
        }
    }

        // Chiudi il file dopo aver finito di leggere
        file_input.close();
    //fine debug lettura file
    //stampo le distanze
    //calolca i centri dei cerchi
    float incrementTheta = 0.005774;
    std::cout << "incremento theta: " << incrementTheta << "\n";
    std::vector<Point> circle_centers_var = circle_centers(distanze, incrementTheta);

    //stampa i centri dei cerchi
    for(int i = 0; i < circle_centers_var.size(); i++) {
        std::cout << "centro cerchio " << i+1 << ": " << circle_centers_var[i].x << " " << circle_centers_var[i].y << "\n";
    }

   
    return 0;
}
std::vector<float> clean_first_20(std::vector<float> ranges){
    std::vector<float> ranges_clean;
    for(int i = 20; i < ranges.size()-20; i++){
        ranges_clean.push_back(ranges[i]);
    }
    return ranges_clean;
}
void calc_first_derivative_polar(std::vector<float> data, std::vector<float> &output, float incrementTheta){
    for(int i = 0; i < data.size()-1; i++){
        output.push_back(findiff(data[i+1], data[i], incrementTheta));
    }
}

void divide_in_segment(std::vector<float> ranges,std::vector<float> f_deriv, std::vector<std::vector<float>> &segmentedData, std::vector<int> &segment_index_begin){
    int segment_index = 0;
    double falg_begin = true;

    std::vector<float> segment;
    for(int i = 0; i < ranges.size()-1; i++){
        if(std::fabs(f_deriv[i]) < THRASHOLD_SEGENMENTATION_DERIVATIVE){
            if(falg_begin){
                segment_index_begin.push_back(i);
                falg_begin = false;
            }
            segment.push_back(ranges[i]);
        }
        else{
            if(segment.size() > 0)
                segmentedData.push_back(segment);
            segment.clear();
            falg_begin = true;
        }
    }
    if(segment.size() > 0)
        segmentedData.push_back(segment);
}

void segmentPolar_to_segmentCartesian(std::vector<std::vector<float>> segmentedData, std::vector<std::vector<Point>> &segmentedDataCartesian, float initial_theta, float incrementTheta){
    for(int i = 0; i < segmentedData.size(); i++){
        std::vector<Point> segmentCartesian;
        int initial_theta_i = initial_theta + (segmentedData[i].size()/2)*incrementTheta;
        for(int j = 0; j < segmentedData[i].size(); j++){
            segmentCartesian.push_back(Point(segmentedData[i][j], initial_theta_i + (j*incrementTheta)));
        }
        segmentedDataCartesian.push_back(segmentCartesian);
    }
}

std::vector<std::vector<Point>>smooth_data_cartesian(std::vector<std::vector<Point>> dataSegemntedPoint, int window_size){
    std::vector<std::vector<Point>> dataSegemntedPoint_smooth;
    for(int i = 0; i < dataSegemntedPoint.size(); i++){
        std::vector<Point> segment_smooth;
        for(int j = 0; j < dataSegemntedPoint[i].size(); j++){
            if (i < window_size || i >= dataSegemntedPoint[i].size() - window_size) {
                // Se il dato è troppo vicino al bordo, non è possibile calcolare la media
                segment_smooth.push_back(dataSegemntedPoint[i][j]);
            }else {
                // Calcola la media dei dati nel range
                double total_y = 0;
                for (int k = j - window_size; k < j + window_size + 1; ++k) {
                    total_y += dataSegemntedPoint[i][k].y;
                }
                int mean = total_y / (window_size * 2 + 1);
                segment_smooth.push_back(Point(dataSegemntedPoint[i][j].x, mean, true));
            }
        }
        dataSegemntedPoint_smooth.push_back(segment_smooth);
    }
    return dataSegemntedPoint_smooth;
}




std::vector<Point> circle_centers(std::vector<float> ranges, float incrementTheta){
    std::vector<float> ranges_clean = clean_first_20(ranges);


    //calcualte the first derivative of the polar data
    std::vector<float> first_derivative_polar;
    calc_first_derivative_polar(ranges_clean, first_derivative_polar,incrementTheta);

    //divide in segment
    std::vector<std::vector<float>> segmentedData;
    std::vector<int> segment_index_begin;

    divide_in_segment(ranges_clean,first_derivative_polar, segmentedData, segment_index_begin);

    //trasform each segment in cartesian
    std::vector<std::vector<Point>> segmentedDataCartesian;
    int const initial_theta_centerd = 3.14/2;
    segmentPolar_to_segmentCartesian(segmentedData, segmentedDataCartesian,initial_theta_centerd, incrementTheta);

    //smooth segenment
    std::vector<std::vector<Point>> segmentedDataCartesian_smooth;
    segmentedDataCartesian_smooth = smooth_data_cartesian(segmentedDataCartesian, WINDOW_SIZE_SMOOTH);

}

